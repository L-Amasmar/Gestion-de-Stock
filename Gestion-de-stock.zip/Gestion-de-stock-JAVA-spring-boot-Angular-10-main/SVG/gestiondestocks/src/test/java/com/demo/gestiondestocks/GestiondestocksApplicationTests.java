package com.demo.gestiondestocks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestiondestocksApplicationTests {

	@Test
	void contextLoads() {
	}

}
