package com.demo.gestiondestocks.dto;

public class ArticleaDto {
}
