package com.demo.gestiondestocks.utils;

public interface Constants {


    public  static  String APP_ROUTE = "gestiondestock/v1";
}
